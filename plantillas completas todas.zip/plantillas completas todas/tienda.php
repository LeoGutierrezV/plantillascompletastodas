<?php include 'layoust/head.php';?> 
    <div class="bg-light py-3">
      <div class="container">
        <div class="row">
          <div class="col-md-12 mb-0"><a class="text-black" href="Inicio">Home</a> <span class="mx-2 mb-0">/</span>
           <strong class="text-black">Tienda</strong></div>
        </div>
      </div>
    </div>

    <div class="site-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-9 order-2">
            <div class="row">
              <div class="col-md-12 mb-5">
                <div class="float-md-left mb-4"><h2 class="text-black h5">Bienvenidos a mi Universo</h2></div>
              </div>
            </div>
            <div class="row mb-5">
              <?php
                include 'php/conexion.php';
                $resultado = $conexion -> query('select productos.*,categorias.nombre as categoria,tallasfsw.tallas from productos
                inner join categorias on productos.id_categoria = categorias.id inner join tallasfsw on productos.talla = tallasfsw.id_talla 
                where inventario>0 order by id')or die($conexion->error);
                while($fila = mysqli_fetch_array($resultado)){
              ?>
              <div class="col-sm-6 col-lg-4 mb-4" data-aos="fade-up">
                <div class="block-4 text-center">
                  <figure class="image">
                    <a class="block-2-item" href="shop-single.php?id=<?php echo $fila['id'];?>"><img src="images/<?php echo $fila['imagen'];?>" alt="Image placeholder" class="img-fluid"></a>
                  </figure>
                  <div class="block-4-text p-4">
                    <h3><a class="EYELEVATION" href="shop-single.php?id=<?php echo $fila['id'];?>"><?php echo $fila['nombre'];?></a></h3>
                    <h6><p class="mb-0"><?php echo $fila['categoria'];?></p></h6>
                    <h6><p class="mb-0"><?php echo $fila['color'];?></p></h6>
                    <p class="text-primary font-weight-bold text-black">S/.<?php echo $fila['precio'];?></p>
                  </div>
                </div>
              </div>
            <?php }?>
            </div>
          </div>

          <div class="col-md-3 order-1 mb-5 mb-md-0">
            <div class="border p-4 rounded mb-4">
              <h3 class="mb-3 h6 text-uppercase text-black d-block">Categorias</h3>
              <ul class="list-unstyled mb-0">
                <?php 
                  $re= $conexion->query("select * from categorias ");
                  while ($f= mysqli_fetch_array($re)) {
                ?>
                <li class="mb-1">
                    <a href="./busqueda2.0.php?texto=<?php echo $f['nombre'];?>" class="d-flex text-black">
                      <span><h6><?php echo $f['nombre'];?></h6></span>
                      <span class="text-black ml-auto">
                        <?php
                          $re2=$conexion->query("select count(*) from productos where id_categoria =".$f['id']);
                          $fila = mysqli_fetch_row($re2);
                          echo $fila[0];
                        ?>
                          
                      </span>
                    </a>
                </li>
                <?php }?>
              </ul>
            </div>

            <div class="border p-4 rounded mb-4">

              <div class="mb-4">
                <h3 class="mb-3 h6 text-uppercase text-black d-block">Talla</h3>
                <?php
                    $re= $conexion->query("select * from tallasfsw");
                    while ($f= mysqli_fetch_array($re)) {
                ?>
                <label for="s_sm"><!--class="d-flex"-->
                <div class="block-26 mb-2">
				               <ul>
				                  <li><a href="./busqueda2.0.php?texto=<?php echo $f['tallas'];?>"><?php echo $f['tallas'];?></a></li>
				               </ul>
				        </div>
                </span>
                </label>
                <?php }?>
              </div>

              <div class="mb-4">
                <h3 class="mb-3 h6 text-uppercase text-black d-block">Color</h3>
                <?php
                    $re= $conexion->query("select * from productos");
                    while ($f= mysqli_fetch_array($re)) {
                ?>
                  <a href="./Search?texto=<?php echo $f['color'];?>" class="d-flex color-item align-items-center" >
                    <span class="text-black"><?php echo $f['color'];?></span>
                  </a>
                <?php }?>
              </div>

            </div>
          </div>
        </div>

        
      </div>
    </div>
    <?php include('./layoust/foot.php'); ?> 