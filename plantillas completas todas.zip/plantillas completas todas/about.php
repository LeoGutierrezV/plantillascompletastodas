<?php include 'layoust/head.php'; ?> 

    <div class="video">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 text-center">
            <div class="about-wrap text-black">
              <p>Un privilegio eterno, 𝐔𝐍𝐈𝐕𝐄𝐑𝐒𝐎 fabriziosurferwinn una marca</p>
              <p>independiente con gran influencia de la onda ESTÉTICA</p>
                <br>
                <br>
              <!--<img class="col-6" src="images/FIRMA FSW.png" width="80px" height="auto">-->
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--========================================================-->
    
    

    
    <!--=======================================================-->
    <div class="video">
      <div class="container">
        <div class="row">
          <div class="col-sm-6 text-center">
          <ul class="slider">
            <li>
              <input type="radio" id="sbutton1" name="sradio" checked>
              <label for="sbutton1"></label>
              <img src="images/1.png" alt="">
            </li>
            <li>
              <input type="radio" id="sbutton3" name="sradio">
              <label for="sbutton3"></label>
              <img src="images/3.png" alt="">
            </li>
            <li>
              <input type="radio" id="sbutton5" name="sradio">
              <label for="sbutton5"></label>
              <img src="images/5.png" alt="">
            </li>
            <li>
              <input type="radio" id="sbutton7" name="sradio">
              <label for="sbutton7"></label>
              <img src="images/7.png" alt="">
            </li>      
          </ul>
          </div>

          <div class="col-sm-6 text-center">
            <ul class="slider1">
              <li>
                <input type="radio" id="sbutton2" name="sradio2" checked>
                <label for="sbutton2"></label>
                <img src="images/2.png" alt="">
              </li>
              <li>
                <input type="radio" id="sbutton4" name="sradio2">
                <label for="sbutton4"></label>
                <img src="images/4.png" alt="">
              </li>
              <li>
                <input type="radio" id="sbutton6" name="sradio2">
                <label for="sbutton6"></label>
                <img src="images/6.png" alt="">
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="video">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 mb-3 conteiner-youtube">
          <iframe class="conteiner2-youtube2" src="https://www.youtube.com/embed/KqAUnbXGE3I" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
          </div>
          </div>
        </div>
    </div>

    
                <div class="space"></div>
  

                <div class="header__menu">
      <a href="https://instagram.com/fsw.universo?r=nametag"><i class="fab fa-instagram"></i></a>
            <ul>
                <p>Sigueme en</p>
                <li><a href="https://instagram.com/fsw.universo?r=nametag">@fsw.universo</a></li>
            </ul>
        </div>

    <div class="gallery-container">
      <div class="gallery-item">
        <img id="gallery-item-index" src="https://firebasestorage.googleapis.com/v0/b/fabriziosurferwinn.appspot.com/o/instagram%2Feyelevation-5.jpg?alt=media&token=48003137-9be8-4584-8e44-cbf84a6e0df9">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="https://firebasestorage.googleapis.com/v0/b/fabriziosurferwinn.appspot.com/o/instagram%2Feyelevation-11.jpg?alt=media&token=72da84cc-d7a2-4ddf-a8b2-1d4e6081e16b">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="https://firebasestorage.googleapis.com/v0/b/fabriziosurferwinn.appspot.com/o/instagram%2Feyelevation-8.jpg?alt=media&token=12cff170-59dd-489b-a746-30b00db7774a">
      </div>
      <div class="gallery-item">
        <img id="gallery-item-index" src="https://firebasestorage.googleapis.com/v0/b/fabriziosurferwinn.appspot.com/o/instagram%2Feyelevation-6.jpg?alt=media&token=fcc693d8-26b9-462d-907b-40bd100ff947">
      </div>
    </div>

    <footer class="colorlib-footer">
      <div class="colorlib-widget-1">
        <img id="colorlib-logo-2" src="images/OJO.png" alt="logo" height="50" width="85">

        <ul class="colorlib-social-icons">
          <li><a href="https://www.facebook.com/FabrizioSW"><i class="icon-facebook"></i></a></li>
          <li><a href="https://instagram.com/fsw.universo?r=nametag"><i class="icon-instagram"></i></a></li>
          <li><a href="https://www.youtube.com/channel/UCNkn3KZKxLTXxc34F3Fr5aQ"><i class="icon-youtube"></i></a></li>
          <li><a href="https://www.behance.net/fabriziosw"><i class="icon-behance2"></i></a></li>
          <li><a href="Inicio"><i class="icon-earth"></i></a></li>
        </ul>
      </div>
 

      <div class="colorlib-widget">
        <h2>POLITICAS DE PRIVACIDAD</h2>
        <p>
          <ul class="colorlib-footer-links">
            <li><a class="text-white" href="PoliticasPrivacidad">Políticas de Privacidad</a></li>
          </ul>
        </p>
      </div>
      <div class="colorlib-widget">
        <h2>INFORMACIÓN</h2>
        <p>
          <ul class="colorlib-footer-links">
            <li><a class="text-white" href="PreguntasFrecuentes">Preguntas Frecuentes</a></li>
          </ul>
        </p>
      </div>

      <div class="colorlib-widget-1">
        <br>
        <br>
          <ul class="colorlib-social-icons-1">
            <li><a href="https://www.facebook.com/FabrizioSW"><i class="icon-facebook"></i></a></li>
            <li><a href="https://instagram.com/fsw.universo?r=nametag"><i class="icon-instagram"></i></a></li>
            <li><a href="https://www.youtube.com/channel/UCNkn3KZKxLTXxc34F3Fr5aQ"><i class="icon-youtube"></i></a></li>
            <li><a href="https://www.behance.net/fabriziosw"><i class="icon-behance2"></i></a></li>
            <li><a href="Inicio"><i class="icon-earth"></i></a></li>
          </ul>
      </div>
      <div class="copy">
        <p>COPYRIGHT 2021 &copy; fabriziosurferwinn <span class="color-span"></span></p>
      </div>

    </footer>

  </div>

  <script type="text/javascript" src="js/main.js" ></script>
  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/main2.0.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/magnific-popup-options.js"></script>
</body>
</html>