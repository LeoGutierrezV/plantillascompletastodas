<?php 
  session_start();

  if (!isset($_SESSION['datos_login'])) {
      header("Location: ../index.php");
  }
  $arregloUsuario = $_SESSION['datos_login'];
  if ($arregloUsuario['nivel']!= 'cliente') {
    header("Location: ../index.php");
  }
?>

<?php include 'layoust/head.php'; ?> 



<?php include('./layoust/foot.php'); ?> 